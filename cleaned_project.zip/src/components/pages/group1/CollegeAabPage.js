
import React from 'react';
import CollegeAabSection from '../../organisms/group1/CollegeAabSection';

export default function CollegeAabPage() {
  return (
    <div>
      <CollegeAabSection />
    </div>
  );
}
