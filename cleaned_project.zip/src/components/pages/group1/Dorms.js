import React from 'react'

export default function Dorms() {
  return (
    <div>
      <h1>Konviktet</h1>
    </div>
  )
}
