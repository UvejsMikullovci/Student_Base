import React from "react";
import CollagesSection from "../../../organisms/group1/Collages/CollagesSection";

function Collages() {
  return React.createElement("div", null, React.createElement(CollagesSection));
}

export default Collages;
