import React from 'react'
import './panelCollageAplicants.css'

function panelCollageAplicants() {
  return (
    <div>panelCollageAplicants</div>
  )
}

export default panelCollageAplicants