import React from 'react'

export default function panelDormsProfile() {
    return (
        <div>
            <h1>Panel Dorms Profile Page</h1>
        </div>
    )
}
