import React from "react";
import "./Button.css";
import Paneli from "../../pages/Panels/StudentPanel/StudentPanelApplications/StudentPanelApplications"

const Button = ({ label, onClick }) => {
  return (
    <button className="btn" onClick={onClick}>{label}</button>
  );
};

export default Button;
