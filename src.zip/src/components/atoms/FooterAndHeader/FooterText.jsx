import React from "react";

const FooterText = ({ text }) => {
  return <p className="footer-text">{text}</p>;
};

export default FooterText;