import React from "react";
import "./Heading.css";

export function Heading(){
    return(
        <h1 className="HomePageheading">
            Your Gateway to <br></br><span>Higher Education</span> in Kosovo
        </h1>
    );
}
