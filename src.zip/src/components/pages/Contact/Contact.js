import React from "react";
import ContactContent from "../../organisms/group3/ContactContent";

export default function ContactPage() {
  return (
    <main>
      <ContactContent />
    </main>
  );
}
