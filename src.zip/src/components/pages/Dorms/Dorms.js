import React from 'react'

export default function Dorms() {
  return (
    <div>Dorms</div>
  )
}
