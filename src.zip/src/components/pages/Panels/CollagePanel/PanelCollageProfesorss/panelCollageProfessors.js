import React from 'react'
import './panelCollageProfessors.css'

function panelCollageProfessors() {
  return (
    <div>panelCollageProfessors</div>
  )
}

export default panelCollageProfessors