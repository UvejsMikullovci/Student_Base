import React from 'react'
import './panelCollageSettings.css'

function panelCollageSettings() {
  return (
    <div>panelCollageSettings</div>
  )
}

export default panelCollageSettings