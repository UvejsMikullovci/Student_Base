import React from 'react'

export default function PanelLandlordProfile() {
  return (
    <div>PanelLandlordProfile</div>
  )
}
