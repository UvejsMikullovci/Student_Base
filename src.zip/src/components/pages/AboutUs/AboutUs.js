import React from "react";
import AboutContent from "../../organisms/group3/AboutContent";


export default function RrethNeshPage() {
  return (
    <main>
      <AboutContent />
    </main>
  );
}
